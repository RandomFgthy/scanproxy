# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


import os
import argparse
import requests
import json


# функция сканирования сети
def do_ping_sweep(ip, num_of_host):
    ip_parts = ip.split('.')
# Добавить проверки адрес - это число и в допустимом диапазоне
    network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
    scanned_ip = network_ip + str(int(ip_parts[3]) + num_of_host)
    response = os.popen(f'ping -c 1 {scanned_ip}')
    res = response.readlines()
    print(f"[#] Result of scanning: {scanned_ip} [#]\n{res[1]}", end='\n\n')

# функция прокси сервера
def sent_http_request(method, target, headers=None, payload=None):
    headers_dict = dict()
    if headers:
        headers_list = headers.split("---") # если заголовков несколько, разбить их по ---
        for header in headers_list:
            header_name = header.split(":")[0]
            header_value = header.split(":")[1:]
            headers_dict[header_name] = ":".join(header_value)

    if method == "GET":
        response = requests.get(target, headers=headers_dict)
    elif method == "POST":
        response = requests.post(target, headers=headers_dict, data=payload)
    print(
        f"[#] Response status code: {response.status_code}\n"
        f"[#] Response headers: {json.dumps(dict(response.headers), indent=4, sort_keys=True)}\n"
        f"[#] Response content:\n {response.text}"
    )

parser = argparse.ArgumentParser(description='Network scanner')
parser.add_argument('task', choices=['scan', 'GET', 'POST'], help='Network scan or GET|POST request')
parser.add_argument('-i', '--ip', type=str, help='IP address')
parser.add_argument('-n', '--num_of_hosts', type=int, help='Number of hosts')

parser.add_argument('-t', '--target', type=str, help='Request target')
parser.add_argument('-hd', '--headers', type=str, help='Request headers name:value---name:value etc.')
parser.add_argument('-p', '--payload', type=str, help='Payload for POST')
args = parser.parse_args()
if args.task == 'scan':
    for host_num in range(args.num_of_hosts):
        do_ping_sweep(args.ip, host_num)
elif args.task == 'GET':
    sent_http_request(args.task, args.target, args.headers, args.payload)
else:
    post_request_payload = str(input("Payload:"))
    sent_http_request(args.task, args.target, args.headers, args.payload)

# Подать в строку python scanner.py sendhttp -t https://google.com -m GET -hd Accept-Language:ru
#scanner.py — название файла с кодом утилиты;
# sendhttp — название задачи, которую требуется решить (в данном случае это отправка HTTP-запросов, также есть задание scan, которое осуществляет сканирование сети);
# -t — аргумент, который указывается для задания цели для отправки HTTP-запроса;
# -m — аргумент, который указывается для задания типа запроса (POST или GET);
# -hd — аргумент, который указывается для задания заголовков.
# See PyCharm help at https://www.jetbrains.com/help/pycharm/
